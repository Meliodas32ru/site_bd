<?php
    $connect = "127.0.0.1";
    $user = "root";
    $password = "";
    $db = "ODS_DB";

    $link = mysqli_connect($connect,$user,$password,$db);

    if (!$link){
        echo "Ошибка. Нет соединения";
        echo '<br>';
        echo "Код ошибки: " . mysqli_connect_error();
        echo '<br>';
        echo "Текст ошибки: " . mysqli_connect_error();
        exit;
    }
?>