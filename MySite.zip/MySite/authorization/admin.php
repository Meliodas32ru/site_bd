<?php
$exit = $_POST['exit'];
if (!empty($exit)) {
    unset($_SESSION['login']);
    unset($_SESSION['pass']);
exit("<html><head><title>Загрузка..</title><meta http-equiv='Refresh' 
content='0; URL=index.php'></head></html>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body style="background-image: url(/assets/fon.jpg);">
<div class="wrapper">
    <main>
        <div class="header">
            <ul class="nav nav-pills">
                <li href="/">
                    <img class="logo" src="/assets/aurora.png">
                </li>
                <li class="nav-item">
                    <a href="admin.php" class="nav-link">Главная</a>
                </li>
                
                <li class="nav-item">
                    <a href="/table/BUY_TICKET/index.php" class="nav-link">Покупка билета</a>
                </li>
                <li class="nav-item">
                    <a href="/table/PASSANGER/index.php" class="nav-link">Пассажиры</a>
                </li>
                <li class="nav-item">
                    <a href="/table/SCHEDULE/index.php" class="nav-link">Расписание</a>
                </li>
                <li class="nav-item">
                    <a href="/table/TICKETS/index.php" class="nav-link">Билеты</a>
                </li>
                <li class="nav-item">
                    <a href="/table/TRAINS/index.php" class="nav-link">Поезда</a>
                </li>

                <li class="nav-item">
                    <a href="/index.php" class="nav-link">Выйти</a>
                </li>
            </ul>
            <div class="main">
                <div class="text-block">
                <h1 class="display-5 fw-bold text1">Добро пожаловать на сайт железной дороги! <br>
                    Мы рады приветствовать вас и предложить полезную информацию о нашей компании и услугах, которые мы предоставляем. <br>
                    На нашем сайте вы найдете информацию о графике движения поездов, стоимости билетов,  а также возможностью покупки билетов . <br> 
                    Мы стремимся обеспечить комфортное и безопасное путешествие для всех наших пассажиров.
                </h1>
                <h2 class="display-5 fw-bold text2"> 
                    Как купить билет на поезд по выгодной цене?
                </h2>
            </div>

            <div class="info" >
                    <div class="info__item1" style="background-color: white;">
                            <p><img src="../assets/skidka.svg"></p>
                            <h2>Скидки для <br>  школьников</h2>
                            <h4 class="txt1">Дети от 10 до 17 лет<br> могут проехать в <br> плацкарте со скидкой до 50% </h4>
                    </div>

                    <div class="palka"></div>

                    <div class="info__item1" style="background-color: white;">
                        <div class="item2">
                            <p><img src="../assets/chem.svg"><br></p>
                            <h2>Чем раньше, <br> тем выгоднее</h2>
                        </div>
                        <h4 class="txt1">Билеты будут дешевле,<br> если покупать за 90 суток<br>  до отправления</h4>
                    </div>
                    
                    <div class="palka"></div>

                    <div class="info__item1" style="background-color: white;">
                        <div class="item3">
                            <p><img src="../assets/123.svg"></p>
                            <h2>Верхние полки <br> за полцены</h2>
                        </div>
                        <h4 class="txt1">Перевозчики часто <br> предлагают скидки до 50%.<br> Выходит дешевле,<br>чем в плацкарте</h4>
                    </div>

                    <div class="palka"></div>

                    <div class="info__item1" style="background-color: white;">
                        <div class="item4">
                            <p><img src="../assets/polki.svg"></p>
                            <h2>Нижние полки <br>по постоянной цене</h2>
                        </div>
                        <h4 class="txt1">Самые популярные полки<br> подальше от туалета.<br>Их цена остаётся одинаковой </h4>
                    </div>
            </div>
        </main>
    </div>
</body>
</html>
