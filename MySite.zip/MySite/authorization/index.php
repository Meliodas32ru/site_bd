<?php
session_start();
include('connect.php');
        $login = stripslashes( htmlspecialchars(trim($_POST['login'])));
        $pass = trim($_POST['pass']);
    if (!empty($login) && !empty($pass)){
        $sql = "SELECT `id_access`, `login`, `password`, `access` FROM 
`access` where `login`='$login' and `password` = '$pass'";
        $result = mysqli_query($link, $sql);
        $row = mysqli_num_rows ($result);
        if ($row == 0) {
            exit("Неверный логин или пароль!");
        } else
            {
                $row1 = mysqli_fetch_array($result);
                if ($row1['access'] == 'admin') {
                header('Location: admin.php');
                }
                if ($row1['access'] == 'user') {
                header('Location: user.php');
                }
        }
    }
mysqli_close($link);
session_destroy();
?>
<!DOCTYPE html>
<head>
        <title> Авторизация</title>
        <link rel="stylesheet" type="text/css" href="/css/index3.css">
        </script>
</head>
<body style="background-image: url(/assets/fon.jpg);">
<a href="/"><img class="logo" src="/assets/aurora.png" width="100px" height = "20px"></a>
        <form method="post" name="myForm" class="main">
            <p>Логин: <input type="text" name="login"> </p>
            <p>Пароль: <input type="password" name="pass"> </p>
            <input type="submit" value="Отправить" name="enter"> 
        <a href="/index.php"> Выход </a>
</form>
</body>
</html>