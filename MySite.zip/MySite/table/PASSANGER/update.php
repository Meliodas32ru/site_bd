<?php
include 'connect.php';
//Если переменная Name передана
if (isset($_POST['PASSANGER_ID'])) {
//Если это запрос на обновление, то обновляем
if (isset($_GET['red_id'])) {
$sql_update = "UPDATE PASSANGER SET PASSANGER_ID = '{$_POST['PASSANGER_ID']}', PASSANGERS_FULL_NAME = '{$_POST['PASSANGERS_FULL_NAME']}', PASSPORT = '{$_POST['PASSPORT']}', BENEFITS = '{$_POST['BENEFITS']}' WHERE PASSANGER_ID = {$_GET['red_id']}";
$result_update = mysqli_query($link,
$sql_update);}

if ($result_update) {
    echo '<p>Успешно!</p>';
} 
else {
    echo '<p>Произошла ошибка: ' . mysqli_error($link). '</p>';
}}
if (isset($_GET['red_id'])) 
{
    $sql_select = "SELECT  PASSANGER_ID, PASSANGERS_FULL_NAME, PASSPORT, BENEFITS FROM PASSANGER WHERE PASSANGER_ID = {$_GET['red_id']}";
    $result_select = mysqli_query($link, $sql_select);
    $row = mysqli_fetch_array($result_select);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Редактирование </title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="" method="post">
<table>
    <tr>
        <td>Код пассажира</td>
        <td><input type="integer" name="PASSANGER_ID" value="<?=
    isset($_GET['red_id']) ? $row['PASSANGER_ID'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>ФИО</td>
        <td><input type="text" name="PASSANGERS_FULL_NAME" value="<?=
        isset($_GET['red_id']) ? $row['PASSANGERS_FULL_NAME'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>паспорт</td>
        <td><input type="integer" name="PASSPORT" value="<?=
        isset($_GET['red_id']) ? $row['PASSPORT'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>льгота</td>
        <td><input type="integer" name="BENEFITS" value="<?=
        isset($_GET['red_id']) ? $row['BENEFITS'] : ''; ?>"></td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit"value="Сохранить"></td>
    </tr>
</table>
</form>
    </table>
        <form action="header.php" method="post">
        <input type="submit" value="Вернуться назад">
    </form>
</body>
</html>