<?php
    include "connect.php";

    $PASSANGER_ID = htmlentities(trim($_POST['PASSANGER_ID']));
    $PASSANGERS_FULL_NAME = htmlentities(trim($_POST['PASSANGERS_FULL_NAME']));
    $PASSPORT = htmlentities(trim($_POST['PASSPORT']));
    $BENEFITS = htmlentities(trim($_POST['BENEFITS']));

    if (isset($PASSANGER_ID) && isset($PASSANGERS_FULL_NAME) && isset($BENEFITS) && isset($PASSPORT) ){
        $sql = "INSERT INTO PASSANGER (PASSANGER_ID,PASSANGERS_FULL_NAME,BENEFITS,PASSPORT) VALUE ('$PASSANGER_ID', '$PASSANGERS_FULL_NAME', '$BENEFITS', '$PASSPORT')";
        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "Данные добавлены!";
        } else {
            echo "При добавление данных произошла ошибка!" . mysqli_error($link);
            exit;
        }

        mysqli_close($link);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="../header.php" method="POST">
        <input type = "submit" value="Вернуться назад">
    </form>
</body>
</html>