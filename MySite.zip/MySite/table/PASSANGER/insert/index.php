<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="insert.php" method="POST" name="action">
        <table>
        <tr>
        <td>Код пассажира</td>
        <td><input type="integer" name="PASSANGER_ID" value="<?=
    isset($_GET['red_id']) ? $row['PASSANGER_ID'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>ФИО</td>
        <td><input type="text" name="PASSANGERS_FULL_NAME" value="<?=
        isset($_GET['red_id']) ? $row['PASSANGERS_FULL_NAME'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>паспорт</td>
        <td><input type="integer" name="PASSPORT" value="<?=
        isset($_GET['red_id']) ? $row['PASSPORT'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>льгота</td>
        <td><input type="integer" name="BENEFITS" value="<?=
        isset($_GET['red_id']) ? $row['BENEFITS'] : ''; ?>"></td>
    </tr>

            <tr>
                <td>Добавить</td>
                <td><input type="submit" name="insert" value="Добавить"></td>
            </tr>
            <tr>
                <td>Очистить</td>
                <td><input type="reset" name="reset" value="Очистить"></td>
            </tr>

        </table>
    </form>
</body>
</html>