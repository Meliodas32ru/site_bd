<?php
include 'connect.php';
    if (isset($_GET['del_id'])){ 
    $sql_delete = "DELETE FROM PASSANGER WHERE PASSANGER_ID = {$_GET['del_id']}"; 
    $result_delete = mysqli_query ($link, $sql_delete); 
    if ($result_delete) { 
        header('Location: index.php'); 
    } 
    else { 
        echo '<p>Произошла ошибка: ' . 
        mysqli_error($link) . '</p>'; 
    }} 
?> 
<!DOCTYPE html> 
<html> 
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> 
    <link rel="stylesheet" href="/css/style1.css">
</head>
<body style="background-color: green">
    <div class="header">
                <ul class="nav nav-pills">
                <li href="/">
                    <img class="logo" src="/assets/aurora.png">
                </li>
                <li class="nav-item">
                    <a href="/authorization/admin.php" class="nav-link">Главная</a>
                </li>
                <li class="nav-item">
                    <a href="/index.php" class="nav-link">Выйти</a>
                </li>
            </ul>
</div>
    <h2 class="title"> Таблица "Пассажиры" </h2>
    <form method="post">
        <table>
            <tr>
                <td>
                    <input type="text" name="poisk" value="<?=$_POST['poisk']; ?>" class="poisk" placeholder="Поиск записи">
                </td>
                <td>
                    <input type="submit" name="ok" value="ok">
                </td>
            </tr>
        </table>
    </form>


<form action="insert/index.php" method="POST">
                <input type = "submit" value="добавить запись" class="button-27">
    </form>
    <ul class="nav nav-pills">
    <li class="nav-item"> <a href="index.php?sort=PASSANGERS_FULL_NAME-asc" class="nav-link"> ФИО от А до Я </a></li>
    <li class="nav-item"><a href="index.php?sort=PASSANGERS_FULL_NAME-desc" class="nav-link"> ФИО от Я до А </a></li>
    <li class="nav-item"> <a href="index.php?sort=PASSPORT-asc" class="nav-link"> Возрастрание поля паспорт </a></li>
    <li class="nav-item"><a href="index.php?sort=PASSPORT-desc" class="nav-link"> Убывание поля паспорт </a></li>
    <li class="nav-item"><a href="index.php?sort=default" class="nav-link"> по умолчанию </a></li>
</ul>

<?php 

$sorting = $_GET['sort'];
$poisk = $_POST['poisk'];

switch ($sorting) {
    case "PASSANGERS_FULL_NAME-asc":
    $sorting_sql = 'ORDER BY PASSANGERS_FULL_NAME ASC';
    break;

    case "PASSANGERS_FULL_NAME-desc":
    $sorting_sql = 'ORDER BY PASSANGERS_FULL_NAME DESC';
        break;
    
    case "PASSPORT-asc":
        $sorting_sql = 'ORDER BY PASSPORT ASC';
        break;
    
        case "PASSPORT-desc":
        $sorting_sql = 'ORDER BY PASSPORT DESC';
            break;
    
        case "default":
        $sorting_sql = '';
            break;
    }



if(empty($poisk)) {
    $sql = "SELECT * FROM PASSANGER $sorting_sql";
    $result = mysqli_query($link, $sql);
    echo '<table border = 1 class="table">'. 
    '<tr>'.
    "<td> Код пассажира </td>".
    "<td> ФИО </td>".
    "<td> паспорт </td>".
    "<td> льгота </td>".
    "<td> Удаление </td>".
    "<td> Редактирование</td>".
    '</tr>';
    while ($row_state = mysqli_fetch_array($result)) {
        echo '<tr>' . 
        "<td> {$row_state['PASSANGER_ID']} </td>" .
        "<td> {$row_state['PASSANGERS_FULL_NAME']} </td>" . 
        "<td> {$row_state['PASSPORT']}</td>". 
        "<td> {$row_state['BENEFITS']}</td>". 
        "<td><a href='?del_id={$row_state['PASSANGER_ID']}'>Удалить</a></td>" .
    "<td><a href='update.php?red_id={$row_state['PASSANGER_ID']}'>Изменить</a></td>" . 
    '</tr>';
    }
    echo '</table>';
} else {
    $sqllike = "SELECT PASSANGER_ID,PASSANGERS_FULL_NAME, PASSANGER_ID, PASSPORT, BENEFITS FROM PASSANGER WHERE PASSANGER_ID LIKE '%$poisk%' OR PASSANGER_ID  LIKE '%$poisk%' OR PASSANGERS_FULL_NAME LIKE '%$poisk%' OR PASSPORT LIKE '%$poisk%' 
    OR BENEFITS LIKE '%$poisk%'";
    $result_like = mysqli_query($link, $sqllike);
    echo '<table border = 1 class="table">'. 
    '<tr>'.
    "<td> Код пассажира </td>".
    "<td> ФИО </td>".
    "<td> паспорт </td>".
    "<td> льгота </td>".
    '</tr>';
    while ($row_staff1 = mysqli_fetch_array($result_like)) {
        echo '<tr>'.
        "<td> {$row_staff1['PASSANGER_ID']} </td>".
        "<td> {$row_staff1['PASSANGERS_FULL_NAME']} </td>" . 
        "<td> {$row_staff1['PASSPORT']} </td>".
        "<td> {$row_staff1['BENEFITS']} </td>".
        '</tr>';
    }  
}

?> 
</table> 
</body> 
</html>