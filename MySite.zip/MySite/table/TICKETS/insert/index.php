<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="insert.php" method="POST" name="action">
        <table>

            <tr>
                <td>Код билета</td>
                <td><input type="integer" name="TICKET_ID"></td>
            </tr>

            <tr>
                <td>Пассажир</td>
                <td>
                    <select name="PASSANGER_ID">
                        <option value="1"> Сидоров С.П. </option>
                        <option value="2"> Сидоров С.П. </option>
                        <option value="3"> Петров А.В.</option>
                        <option value="4"> Миронов В.В. </option>
                        <option value="5"> Леонов Л.Д. </option>
                        <option value="6"> Крюкова Д.В. </option>
                </select></td>
            </tr>

            <tr>
                <td>Тип поезда</td>
                <td>
                    <select name="TRAIN_ID">
                        <option value="1"> скоростной</option>
                        <option value="2"> высокоскоростной </option>
                        <option value="3"> туристический</option>
                </select></td>
            </tr>

            <tr>
                <td>Номер вагона</td>
                <td><input type="integer" name="NUMBER_WAGON"></td>
            </tr>

            <tr>
                <td>Номер места</td>
                <td><input type="integer" name="SEAT_NUMBER"></td>
            </tr>
            <tr>
                <td>Точка отправления</td>
                <td><input type="text" name="WHERE_FROM"></td>
            </tr>
            <tr>
                <td>Точка прибытия</td>
                <td><input type="text" name="WHERE_"></td>
            </tr>
            <tr>
                <td>Дата</td>
                <td><input type="date" name="DATA"></td>
            </tr>

            <tr>
                <td>Добавить</td>
                <td><input type="submit" name="insert" value="Добавить"></td>
            </tr>
            <tr>
                <td>Очистить</td>
                <td><input type="reset" name="reset" value="Очистить"></td>
            </tr>

        </table>
    </form>
</body>
</html>