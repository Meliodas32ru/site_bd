<?php
    include "connect.php";
    $TICKET_ID = htmlentities(trim($_POST['TICKET_ID']));
    $PASSANGER_ID = htmlentities(trim($_POST['PASSANGER_ID']));
    $TRAIN_ID = htmlentities(trim($_POST['TRAIN_ID']));
    $NUMBER_WAGON = htmlentities(trim($_POST['NUMBER_WAGON']));
    $SEAT_NUMBER = htmlentities(trim($_POST['SEAT_NUMBER']));
    $WHERE_FROM = htmlentities(trim($_POST['WHERE_FROM']));
    $WHERE_ = htmlentities(trim($_POST['WHERE_']));
    $DATA = htmlentities(trim($_POST['DATA']));

    if (isset($TICKET_ID) && isset($PASSANGER_ID) && isset($TRAIN_ID) && isset($NUMBER_WAGON) && isset($SEAT_NUMBER) && isset($WHERE_FROM) && isset($WHERE_) && isset($DATA)){
        $sql = "INSERT INTO TICKETS (TICKET_ID,PASSANGER_ID, TRAIN_ID,NUMBER_WAGON,SEAT_NUMBER, WHERE_FROM,WHERE_,DATA) VALUE ( '$TICKET_ID','$PASSANGER_ID', '$TRAIN_ID', '$NUMBER_WAGON', '$SEAT_NUMBER', '$WHERE_FROM', '$WHERE_', '$DATA')";
        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "Данные добавлены!";
        } else {
            echo "При добавление данных произошла ошибка!" . mysqli_error($link);
            exit;
        }

        mysqli_close($link);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="../header.php" method="POST">
        <input type = "submit" value="Вернуться назад">
    </form>
</body>
</html>