<?php
include 'connect.php';
    if (isset($_GET['del_id'])){ 
    $sql_delete = "DELETE FROM TICKETS WHERE TICKET_ID = {$_GET['del_id']}"; 
    $result_delete = mysqli_query ($link, $sql_delete); 
    if ($result_delete) { 
        header('Location: index.php'); 
    } 
    else { 
        echo '<p>Произошла ошибка: ' . 
        mysqli_error($link) . '</p>'; 
    }} 
?> 
<!DOCTYPE html> 
<html> 
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> 
    <link rel="stylesheet" href="/css/style1.css">
</head>
<body style="background-color: green">
    <div class="header">
                <ul class="nav nav-pills">
                <li href="/">
                    <img class="logo" src="/assets/aurora.png">
                </li>
                <li class="nav-item">
                    <a href="/authorization/admin.php" class="nav-link">Главная</a>
                </li>
                <li class="nav-item">
                    <a href="/index.php" class="nav-link">Выйти</a>
                </li>
            </ul>
</div>
    <h2 class="title"> Таблица "Билеты" </h2>
    <form method="post">
        <table>
            <tr>
                <td>
                    <input type="text" name="poisk" value="<?=$_POST['poisk']; ?>" class="poisk" placeholder="Поиск записи">
                </td>
                <td>
                    <input type="submit" name="ok" value="ok">
                </td>
            </tr>
        </table>
    </form>
    <form action="insert/index.php" method="POST">
                <input type = "submit" value="добавить запись" class="button-27">
    </form>

    
<?php 


$poisk = $_POST['poisk'];


if(empty($poisk)) {
    $sql = "SELECT * FROM TICKETS
    INNER JOIN TRAINS ON TICKETS.TRAIN_ID = TRAINS.TRAIN_ID
    JOIN PASSANGER ON TICKETS.PASSANGER_ID = PASSANGER.PASSANGER_ID";
    $result = mysqli_query($link, $sql);
    echo '<table border = 1 class="table">'. 
    '<tr>'.
    "<td> Код билета </td>".
    "<td> Пассажир</td>".
    "<td> Поезд </td>".
    "<td> Номер вагона </td>".
    "<td> Номер места</td>".
    "<td> Откуда </td>".
    "<td> Куда </td>".
    "<td> Дата </td>".
    "<td> Удаление </td>".
    "<td> Редактирование</td>".
    '</tr>';
    while ($row_state = mysqli_fetch_array($result)) {
        echo '<tr>' . 
        "<td> {$row_state['TICKET_ID']} </td>" .
        "<td> {$row_state['PASSANGERS_FULL_NAME']} </td>" .  
        "<td> {$row_state['TYPE_OF_TRAIN']}</td>".
        "<td> {$row_state['NUMBER_WAGON']}</td>".
        "<td> {$row_state['SEAT_NUMBER']}</td>".
        "<td> {$row_state['WHERE_FROM']}</td>".
        "<td> {$row_state['WHERE_']}</td>".
        "<td> {$row_state['DATA']}</td>". 
        "<td><a href='?del_id={$row_state['TICKET_ID']}'>Удалить</a></td>" .
    "<td><a href='update.php?red_id={$row_state['TICKET_ID']}'>Изменить</a></td>" . 
    '</tr>';
    }
    echo '</table>';
} else {
    $sqllike = "SELECT * FROM TICKETS 
    INNER JOIN TRAINS ON TICKETS.TRAIN_ID = TRAINS.TRAIN_ID
    JOIN PASSANGER ON TICKETS.PASSANGER_ID = PASSANGER.PASSANGER_ID
    
    WHERE TICKET_ID LIKE '%$poisk%' OR PASSANGERS_FULL_NAME  LIKE '%$poisk%'  OR TYPE_OF_TRAIN  LIKE '%$poisk%' OR NUMBER_WAGON LIKE '%$poisk%' OR SEAT_NUMBER
    LIKE '%$poisk%' OR WHERE_FROM LIKE '%$poisk%' OR WHERE_ LIKE '%$poisk%' OR DATA LIKE '%$poisk%'";
    $result_like = mysqli_query($link, $sqllike);
    echo '<table border = 1 class="table">'. 
    '<tr>'.
    "<td> Код билета </td>".
    "<td> Пассажира </td>".
    "<td> Поезд </td>".
    "<td> Номер вагона </td>".
    "<td> Номер места</td>".
    "<td> Откуда </td>".
    "<td> Куда </td>".
    "<td> Дата </td>".
    '</tr>';
    while ($row_staff1 = mysqli_fetch_array($result_like)) {
        echo '<tr>'.
        "<td> {$row_staff1 ['TICKET_ID']} </td>" .
        "<td> {$row_staff1 ['PASSANGERS_FULL_NAME']} </td>" .  
        "<td> {$row_staff1 ['TYPE_OF_TRAIN']}</td>".
        "<td> {$row_staff1 ['NUMBER_WAGON']}</td>".
        "<td> {$row_staff1 ['SEAT_NUMBER']}</td>".
        "<td> {$row_staff1 ['WHERE_FROM']}</td>".
        "<td> {$row_staff1 ['WHERE_']}</td>".
        "<td> {$row_staff1 ['DATA']}</td>". 
        '</tr>';
    }  
}

?> 
</table> 
</body> 
</html>