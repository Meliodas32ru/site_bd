<?php
include 'connect.php';
//Если переменная Name передана
if (isset($_POST['TICKET_ID'])) {
//Если это запрос на обновление, то обновляем
if (isset($_GET['red_id'])) {
$sql_update = "UPDATE TICKETS SET TICKET_ID = '{$_POST['TICKET_ID']}', TRAIN_ID = '{$_POST['TRAIN_ID']}', PASSANGER_ID = '{$_POST['PASSANGER_ID']}',
NUMBER_WAGON = '{$_POST['NUMBER_WAGON']}',SEAT_NUMBER = '{$_POST['SEAT_NUMBER']}',WHERE_FROM = '{$_POST['WHERE_FROM']}',WHERE_ = '{$_POST['WHERE_']}',
DATA = '{$_POST['DATA']}' WHERE TICKET_ID = {$_GET['red_id']}";
$result_update = mysqli_query($link,
$sql_update);}

if ($result_update) {
    echo '<p>Успешно!</p>';
} 
else {
    echo '<p>Произошла ошибка: ' . mysqli_error($link). '</p>';
}}
if (isset($_GET['red_id'])) 
{
    $sql_select = "SELECT  TICKET_ID, TRAIN_ID, PASSANGER_ID, NUMBER_WAGON, SEAT_NUMBER, WHERE_FROM, WHERE_, DATA FROM TICKETS WHERE TICKET_ID = {$_GET['red_id']}";
    $result_select = mysqli_query($link, $sql_select);
    $row = mysqli_fetch_array($result_select);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Редактирование </title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="" method="post">
<table>
    <tr>
        <td>Код билета</td>
        <td><input type="integer" name="TICKET_ID" value="<?=
    isset($_GET['red_id']) ? $row['TICKET_ID'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Тип поезда</td>
        <td> <select name="TRAIN_ID">
                <?php
                        include "connect.php";
                        $select = "SELECT TRAIN_ID , TYPE_OF_TRAIN FROM TRAINS ";
                        $result_select = mysqli_query($link, $select);
                        while ($row = mysqli_fetch_array($result_select)) {
                        echo "<option value = '".$row['TRAIN_ID']."'>".$row['TYPE_OF_TRAIN']."</option>";
                        }
                        ?>
                </select></td>
    </tr>
    <tr>
        <td>пассажир</td>
        <td> <select name="PASSANGER_ID">
                <?php
                        include "connect.php";
                        $select = "SELECT PASSANGER_ID , PASSANGERS_FULL_NAME FROM PASSANGER ";
                        $result_select = mysqli_query($link, $select);
                        while ($row = mysqli_fetch_array($result_select)) {
                        echo "<option value = '".$row['PASSANGER_ID']."'>".$row['PASSANGERS_FULL_NAME']."</option>";
                        }
                        ?>
                </select></td>
    </tr>
    <tr>
        <td>Номер вагона</td>
        <td><input type="text" name="NUMBER_WAGON" value="<?=
        isset($_GET['red_id']) ? $row['NUMBER_WAGON'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Номер места</td>
        <td><input type="text" name="SEAT_NUMBER" value="<?=
        isset($_GET['red_id']) ? $row['SEAT_NUMBER'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Точка отправления</td>
        <td><input type="text" name="WHERE_FROM" value="<?=
        isset($_GET['red_id']) ? $row['WHERE_FROM'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Точка прибытия</td>
        <td><input type="text" name="WHERE_" value="<?=
        isset($_GET['red_id']) ? $row['WHERE_'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Дата</td>
        <td><input type="date" name="DATA" value="<?=
        isset($_GET['red_id']) ? $row['DATA'] : ''; ?>"></td>
    </tr>

    <tr>
        <td colspan="2"><input type="submit"value="Сохранить"></td>
    </tr>
</table>
</form>
    </table>
        <form action="header.php" method="post">
        <input type="submit" value="Вернуться назад">
    </form>
</body>
</html>