<?php
include 'connect.php';
    if (isset($_GET['del_id'])){ 
    $sql_delete = "DELETE FROM TRAINS WHERE TRAIN_ID = {$_GET['del_id']}"; 
    $result_delete = mysqli_query ($link, $sql_delete); 
    if ($result_delete) { 
        header('Location: index.php'); 
    } 
    else { 
        echo '<p>Произошла ошибка: ' . 
        mysqli_error($link) . '</p>'; 
    }} 
?> 
<!DOCTYPE html> 
<html> 
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> 
    <link rel="stylesheet" href="/css/style1.css">
</head>
<body style="background-color: green">
    <div class="header">
                <ul class="nav nav-pills">
                <li href="/">
                    <img class="logo" src="/assets/aurora.png">
                </li>
                <li class="nav-item">
                    <a href="/authorization/admin.php" class="nav-link">Главная</a>
                </li>
                <li class="nav-item">
                    <a href="/index.php" class="nav-link">Выйти</a>
                </li>
            </ul>
</div>
    <h2 class="title"> Таблица "Поезда" </h2>
    <form method="post">
        <table>
            <tr>
                <td>
                    <input type="text" name="poisk" value="<?=$_POST['poisk']; ?>" class="poisk" placeholder="Поиск записи">
                </td>
                <td>
                    <input type="submit" name="ok" value="ok">
                </td>
            </tr>
        </table>
    </form>
    <form action="insert/index.php" method="POST">
                <input type = "submit" value="добавить запись" class="button-27">
    </form>
<?php 

$poisk = $_POST['poisk'];


if(empty($poisk)) {
    $sql = "SELECT `TRAIN_ID`,`NUMBER`,`TYPE_OF_TRAIN`, `CAPACITY`, `NUMBER_OF_WAGONS` FROM `TRAINS`";
    $result = mysqli_query($link, $sql);
    echo '<table border = 1 class="table">'. 
    '<tr>'.
    "<td> Код поезда </td>".
    "<td> номер </td>".
    "<td> тип поезда </td>".
    "<td> вместительность</td>".
    "<td> Число вагонов </td>".
    "<td> Удаление</td>".
    "<td> Редактирование</td>".
    '</tr>';
    while ($row_state = mysqli_fetch_array($result)) {
        echo '<tr>' . 
        "<td> {$row_state['TRAIN_ID']} </td>" . 
        "<td> {$row_state['NUMBER']}</td>". 
        "<td> {$row_state['TYPE_OF_TRAIN']}</td>". 
        "<td> {$row_state['CAPACITY']}</td>". 
        "<td> {$row_state['NUMBER_OF_WAGONS']}</td>". 
        "<td><a href='?del_id={$row_state['TRAIN_ID']}'>Удалить</a></td>" .
    "<td><a href='update.php?red_id={$row_state['TRAIN_ID']}'>Изменить</a></td>" . 
    '</tr>';
    }
    echo '</table>';
} else {
    $sqllike = "SELECT * FROM TRAINS WHERE TRAIN_ID LIKE '%$poisk%' OR NUMBER LIKE '%$poisk%' OR TYPE_OF_TRAIN LIKE '%$poisk%' OR NUMBER_OF_WAGONS LIKE '%$poisk%' OR CAPACITY LIKE '%$poisk%'";
    $result_like = mysqli_query($link, $sqllike);
    echo '<table border = 1 class="table">'. 
    '<tr>'.
    "<td> Код поезда </td>".
    "<td> номер </td>".
    "<td> тип поезда </td>".
    "<td> вместительность</td>".
    "<td> Число вагонов </td>".
    '</tr>';
    while ($row_staff1 = mysqli_fetch_array($result_like)) {
        echo '<tr>'.
        "<td> {$row_staff1['TRAIN_ID']} </td>" . 
        "<td> {$row_staff1['NUMBER']}</td>". 
        "<td> {$row_staff1['TYPE_OF_TRAIN']}</td>". 
        "<td> {$row_staff1['CAPACITY']}</td>". 
        "<td> {$row_staff1['NUMBER_OF_WAGONS']}</td>". 
        '</tr>';
    }  
}

?> 
</table> 
</body> 
</html>