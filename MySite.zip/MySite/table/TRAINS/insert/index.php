<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="insert.php" method="POST" name="action">
        <table>
            <tr>
                <td>Код поезда</td>
                <td><input type="integer" name="TRAIN_ID"></td>
            </tr>

            <tr>
                <td>Номер</td>
                <td><input type="integer" name="NUMBER"></td>
            </tr>

            <tr>
                <td>Тип поезда</td>
                <td><input type="text" name="TYPE_OF_TRAIN"></td>
            </tr>

            <tr>
                <td>Вместительность</td>
                <td><input type="integer" name="CAPACITY"></td>
            </tr>

            <tr>
                <td>Количество вагонов</td>
                <td><input type="integer" name="NUMBER_OF_WAGONS"></td>
            </tr>

            <tr>
                <td>Добавить</td>
                <td><input type="submit" name="insert" value="Добавить"></td>
            </tr>
            <tr>
                <td>Очистить</td>
                <td><input type="reset" name="reset" value="Очистить"></td>
            </tr>

        </table>
    </form>
</body>
</html>