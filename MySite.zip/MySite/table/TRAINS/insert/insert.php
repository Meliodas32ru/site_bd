<?php
    include "connect.php";
    $TRAIN_ID = htmlentities(trim($_POST['TRAIN_ID']));
    $NUMBER = htmlentities(trim($_POST['NUMBER']));
    $TYPE_OF_TRAIN = htmlentities(trim($_POST['TYPE_OF_TRAIN']));
    $CAPACITY = htmlentities(trim($_POST['CAPACITY']));
    $NUMBER_OF_WAGONS = htmlentities(trim($_POST['NUMBER_OF_WAGONS']));

    if (isset($TRAIN_ID) && isset($NUMBER) && isset($TYPE_OF_TRAIN) && isset($CAPACITY) && isset($NUMBER_OF_WAGONS)){
        $sql = "INSERT INTO TRAINS (TRAIN_ID,NUMBER,TYPE_OF_TRAIN,CAPACITY,NUMBER_OF_WAGONS) VALUE ( '$TRAIN_ID', '$NUMBER', '$TYPE_OF_TRAIN', '$CAPACITY','$NUMBER_OF_WAGONS')";
        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "Данные добавлены!";
        } else {
            echo "При добавление данных произошла ошибка!" . mysqli_error($link);
            exit;
        }

        mysqli_close($link);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="../header.php" method="POST">
        <input type = "submit" value="Вернуться назад">
    </form>
</body>
</html>