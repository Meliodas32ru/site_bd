<?php
include 'connect.php';
//Если переменная Name передана
if (isset($_POST['TRAIN_ID'])) {
//Если это запрос на обновление, то обновляем
if (isset($_GET['red_id'])) {
$sql_update = "UPDATE TRAINS SET TRAIN_ID = '{$_POST['TRAIN_ID']}', NUMBER = '{$_POST['NUMBER']}', TYPE_OF_TRAIN = '{$_POST['TYPE_OF_TRAIN']}',CAPACITY = '{$_POST['CAPACITY']}' ,NUMBER_OF_WAGONS = '{$_POST['NUMBER_OF_WAGONS']}' WHERE TRAIN_ID = {$_GET['red_id']}";
$result_update = mysqli_query($link,
$sql_update);}

if ($result_update) {
    echo '<p>Успешно!</p>';
} 
else {
    echo '<p>Произошла ошибка: ' . mysqli_error($link). '</p>';
}}
if (isset($_GET['red_id'])) 
{
    $sql_select = "SELECT  TRAIN_ID,  NUMBER, TYPE_OF_TRAIN, CAPACITY,NUMBER_OF_WAGONS FROM TRAINS WHERE TRAIN_ID = {$_GET['red_id']}";
    $result_select = mysqli_query($link, $sql_select);
    $row = mysqli_fetch_array($result_select);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Редактирование </title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="" method="post">
<table>
    <tr>
        <td>Код поезда</td>
        <td><input type="integer" name="TRAIN_ID" value="<?=
        isset($_GET['red_id']) ? $row['TRAIN_ID'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Номер</td>
        <td><input type="integer" name="NUMBER" value="<?=
        isset($_GET['red_id']) ? $row['NUMBER'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Тип поезда</td>
        <td><input type="integer" name="TYPE_OF_TRAIN" value="<?=
        isset($_GET['red_id']) ? $row['TYPE_OF_TRAIN'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>вместительность</td>
        <td><input type="integer" name="CAPACITY" value="<?=
        isset($_GET['red_id']) ? $row['CAPACITY'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Число вагонов</td>
        <td><input type="text" name="NUMBER_OF_WAGONS" value="<?=
        isset($_GET['red_id']) ? $row['NUMBER_OF_WAGONS'] : ''; ?>"></td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit"value="Сохранить"></td>
    </tr>
</table>
</form>
    </table>
        <form action="header.php" method="post">
        <input type="submit" value="Вернуться назад">
    </form>
</body>
</html>