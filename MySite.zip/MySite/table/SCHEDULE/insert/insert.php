<?php
    include "connect.php";
    $SCHEDULE_ID = htmlentities(trim($_POST['SCHEDULE_ID']));
    $TRAIN_ID = htmlentities(trim($_POST['TRAIN_ID']));
    $DISPATCH_POINT = htmlentities(trim($_POST['DISPATCH_POINT']));
    $ARRIVAL_POINT = htmlentities(trim($_POST['ARRIVAL_POINT']));
    $DEPARTURE_TIME = htmlentities(trim($_POST['DEPARTURE_TIME']));
    $ARRIVAL_TIME = htmlentities(trim($_POST['ARRIVAL_TIME']));
    $PERIOD = htmlentities(trim($_POST['PERIOD']));

    if (isset($SCHEDULE_ID) && isset($TRAIN_ID) && isset($DEPARTURE_TIME) && isset($ARRIVAL_POINT) && isset($DISPATCH_POINT) && isset($ARRIVAL_TIME) && isset($PERIOD) ){
        $sql = "INSERT INTO SCHEDULE (SCHEDULE_ID,TRAIN_ID,DEPARTURE_TIME,DISPATCH_POINT,ARRIVAL_POINT,ARRIVAL_TIME,PERIOD) VALUE ( '$SCHEDULE_ID', '$TRAIN_ID', '$DEPARTURE_TIME', '$DISPATCH_POINT', '$ARRIVAL_POINT','$ARRIVAL_TIME','$PERIOD')";
        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "Данные добавлены!";
        } else {
            echo "При добавление данных произошла ошибка!" . mysqli_error($link);
            exit;
        }

        mysqli_close($link);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="../header.php" method="POST">
        <input type = "submit" value="Вернуться назад">
    </form>
</body>
</html>