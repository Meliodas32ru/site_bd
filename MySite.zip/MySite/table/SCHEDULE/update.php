<?php
include 'connect.php';
//Если переменная Name передана
if (isset($_POST['SCHEDULE_ID'])) {
//Если это запрос на обновление, то обновляем
if (isset($_GET['red_id'])) {
$sql_update = "UPDATE SCHEDULE SET SCHEDULE_ID = '{$_POST['SCHEDULE_ID']}', TRAIN_ID = '{$_POST['TRAIN_ID']}', DISPATCH_POINT = '{$_POST['DISPATCH_POINT']}', ARRIVAL_POINT = '{$_POST['ARRIVAL_POINT']}',DEPARTURE_TIME = '{$_POST['DEPARTURE_TIME']}' , ARRIVAL_TIME = '{$_POST['ARRIVAL_TIME']}' , PERIOD = '{$_POST['PERIOD']}' WHERE SCHEDULE_ID = {$_GET['red_id']}";
$result_update = mysqli_query($link,
$sql_update);}

if ($result_update) {
    echo '<p>Успешно!</p>';
} 
else {
    echo '<p>Произошла ошибка: ' . mysqli_error($link). '</p>';
}}
if (isset($_GET['red_id'])) 
{
    $sql_select = "SELECT * FROM SCHEDULE INNER JOIN TRAINS ON SCHEDULE.TRAIN_ID = TRAINS.TRAIN_ID
    WHERE SCHEDULE_ID = {$_GET['red_id']}";
    $result_select = mysqli_query($link, $sql_select);
    $row = mysqli_fetch_array($result_select);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Редактирование </title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="" method="post">
<table>

    <tr>
        <td>ID расписания</td>
        <td><input type="integer" name="SCHEDULE_ID" value="<?=
        isset($_GET['red_id']) ? $row['SCHEDULE_ID'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Тип поезда</td>
        <td> <select name="TRAIN_ID">
                <?php
                        include "connect.php";
                        $select = "SELECT TRAIN_ID , TYPE_OF_TRAIN FROM TRAINS ";
                        $result_select = mysqli_query($link, $select);
                        while ($row = mysqli_fetch_array($result_select)) {
                        echo "<option value = '".$row['TRAIN_ID']."'>".$row['TYPE_OF_TRAIN']."</option>";
                        }
                        ?>
                </select></td>
    </tr>
    <tr>
        <td>Точка отправления</td>
        <td><input type="text" name="ARRIVAL_POINT" value="<?=
        isset($_GET['red_id']) ? $row['ARRIVAL_POINT'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Точка прибытия</td>
        <td><input type="text" name="DISPATCH_POINT" value="<?=
        isset($_GET['red_id']) ? $row['DISPATCH_POINT'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Время отправления</td>
        <td><input type="time" name="DEPARTURE_TIME" value="<?=
        isset($_GET['red_id']) ? $row['DEPARTURE_TIME'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Время прибытия</td>
        <td><input type="time" name="ARRIVAL_TIME" value="<?=
        isset($_GET['red_id']) ? $row['ARRIVAL_TIME'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Период</td>
        <td><input type="text" name="PERIOD" value="<?=
        isset($_GET['red_id']) ? $row['PERIOD'] : ''; ?>"></td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit"value="Сохранить"></td>
    </tr>
</table>
</form>
    </table>
        <form action="header.php" method="post">
        <input type="submit" value="Вернуться назад">
    </form>
</body>
</html>