<?php
include 'connect.php';
//Если переменная Name передана
if (isset($_POST['BUY_TICKET_ID'])) {
//Если это запрос на обновление, то обновляем
if (isset($_GET['red_id'])) {
$sql_update = "UPDATE BUY_TICKET SET BUY_TICKET_ID = '{$_POST['BUY_TICKET_ID']}', TRAIN_ID = '{$_POST['TRAIN_ID']}', PASSANGER_ID = '{$_POST['PASSANGER_ID']}', TICKET_ID = '{$_POST['TICKET_ID']}',DATE1 = '{$_POST['DATE1']}' WHERE BUY_TICKET_ID = {$_GET['red_id']}";
$result_update = mysqli_query($link,
$sql_update);}

if ($result_update) {
    echo '<p>Успешно!</p>';
} 
else {
    echo '<p>Произошла ошибка: ' . mysqli_error($link). '</p>';
}}
if (isset($_GET['red_id'])) 
{
    $sql_select = "SELECT  * FROM BUY_TICKET  INNER JOIN TRAINS ON BUY_TICKET.TRAIN_ID = TRAINS.TRAIN_ID
    JOIN PASSANGER ON BUY_TICKET.PASSANGER_ID = PASSANGER.PASSANGER_ID
    JOIN TICKETS ON BUY_TICKET.TICKET_ID = TICKETS.TICKET_ID
    WHERE BUY_TICKET_ID = {$_GET['red_id']}";
    $result_select = mysqli_query($link, $sql_select);
    $row = mysqli_fetch_array($result_select);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Редактирование </title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="" method="post">
<table>
    <tr>
        <td>Код покупки билета</td>
        <td><input type="integer" name="BUY_TICKET_ID" value="<?=
    isset($_GET['red_id']) ? $row['BUY_TICKET_ID'] : ''; ?>"></td>
    </tr>
    <tr>
        <td>Номер поезда</td>
        <td> <select name="TRAIN_ID">
                <?php
                        include "connect.php";
                        $select = "SELECT TRAIN_ID , NUMBER FROM TRAINS ";
                        $result_select = mysqli_query($link, $select);
                        while ($row = mysqli_fetch_array($result_select)) {
                        echo "<option value = '".$row['TRAIN_ID']."'>".$row['NUMBER']."</option>";
                        }
                        ?>
                </select></td>
    </tr>

    <tr>
        <td>ФИО пассажира</td>
        <td> <select name="PASSANGER_ID">
                <?php
                        include "connect.php";
                        $select = "SELECT PASSANGER_ID , PASSANGERS_FULL_NAME FROM PASSANGER ";
                        $result_select = mysqli_query($link, $select);
                        while ($row = mysqli_fetch_array($result_select)) {
                        echo "<option value = '".$row['PASSANGER_ID']."'>".$row['PASSANGERS_FULL_NAME']."</option>";
                        }
                        ?>
                </select></td>
    </tr>

    <tr>
        <td>Номер вагона</td>
        <td> <select name="TICKET_ID">
                <?php
                        include "connect.php";
                        $select = "SELECT TICKET_ID , NUMBER_WAGON FROM TICKETS ";
                        $result_select = mysqli_query($link, $select);
                        while ($row = mysqli_fetch_array($result_select)) {
                        echo "<option value = '".$row['TICKET_ID']."'>".$row['NUMBER_WAGON']."</option>";
                        }
                        ?>
                </select></td>
    </tr>
    <tr>
        <td>Дата</td>
        <td><input type="date" name="DATE1" value="<?=
        isset($_GET['red_id']) ? $row['DATE1'] : ''; ?>"></td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit"value="Сохранить"></td>
    </tr>
</table>
</form>
    </table>
        <form action="header.php" method="post">
        <input type="submit" value="Вернуться назад">
    </form>
</body>
</html>