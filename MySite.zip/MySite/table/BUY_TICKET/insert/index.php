<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: green; margin-left:600px; margin-top:200px">
    <form action="insert.php" method="POST" name="action">
        <table>
            <!-- <tr>
                <td>Поезд</td>
                <td><input type="integer" name="TRAIN_ID"></td>
            </tr> -->

            <tr>
                <td>ID покупки билета</td>
                <td><input type="integer" name="BUY_TICKET_ID"></td>
            </tr>
            <tr>
                <td>Поезд</td>
                <td>
                    <select name="TRAIN_ID">
                        <option value="1"> 140 </option>
                        <option value="2"> 141 </option>
                        <option value="3"> 142</option>
                        <option value="4"> 143 </option>
                        <option value="5"> 144 </option>
                        <option value="6"> 145 </option>
                </select></td>
            </tr>
            <tr>
                <td>Пассажир</td>
                <td>
                    <select name="PASSANGER_ID">
                        <option value="1"> Сидоров С.П. </option>
                        <option value="2"> Сидоров С.П. </option>
                        <option value="3"> Петров А.В.</option>
                        <option value="4"> Миронов В.В. </option>
                        <option value="5"> Леонов Л.Д. </option>
                        <option value="6"> Крюкова Д.В. </option>
                </select></td>
            </tr>

            <tr>
                <td>Номер вагона</td>
                <td>
                    <select name="TICKET_ID">
                        <option value="1"> 1. </option>
                        <option value="2"> 2 </option>
                        <option value="3"> 3</option>
                        <option value="4"> 4 </option>
                        <option value="5"> 5 </option>
                        <option value="6"> 6 </option>
                </select></td>
            </tr>

            <tr>
                <td>Дата Билета</td>
                <td><input type="date" name="DATE1"></td>
            </tr>

            <tr>
                <td>Добавить</td>
                <td><input type="submit" name="insert" value="Добавить"></td>
            </tr>
            <tr>
                <td>Очистить</td>
                <td><input type="reset" name="reset" value="Очистить"></td>
            </tr>
            

        </table>
    </form>
</body>
</html>