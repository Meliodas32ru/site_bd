<?php
    include "connect.php";
    $BUY_TICKET_ID = htmlentities(trim($_POST['BUY_TICKET_ID']));
    $TRAIN_ID = htmlentities(trim($_POST['TRAIN_ID']));
    $TICKET_ID = htmlentities(trim($_POST['TICKET_ID']));
    $PASSANGER_ID = htmlentities(trim($_POST['PASSANGER_ID']));
    $DATE1 = htmlentities(trim($_POST['DATE1']));

    if ( isset($BUY_TICKET_ID) && isset($TRAIN_ID) && isset($TICKET_ID) && isset($PASSANGER_ID) && isset($DATE1)){
        $sql = "INSERT INTO BUY_TICKET (BUY_TICKET_ID,TRAIN_ID,TICKET_ID,PASSANGER_ID, DATE1) VALUE ( '$BUY_TICKET_ID', '$TRAIN_ID', '$TICKET_ID', '$PASSANGER_ID','$DATE1')";
        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "Данные добавлены!";
        } else {
            echo "При добавление данных произошла ошибка!" . mysqli_error($link);
            exit;
        }

        mysqli_close($link);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="../header.php" method="POST">
        <input type = "submit" value="Вернуться назад">
    </form>
</body>
</html>