<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Проекты</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="/css/style1.css">
</head>

<body style="background-image: url(/assets/fon.jpg);">
    <main>
        <div class="header">
            <ul class="nav nav-pills">
                <li href="/">
                    <img class="logo" src="/assets/aurora.png">
                </li>
                <li class="nav-item">
                    <a href="/authorization/user.php" class="nav-link">Главная</a>
                </li>
                <li class="nav-item">
                    <a href="schedule_user.php" class="nav-link">Расписание</a>
                </li>
                <li class="nav-item">
                    <a href="info_ticket_user.php" class="nav-link">Информация о билетах</a>
                </li>
                <li class="nav-item">
                    <a href="/index.php" class="nav-link">Выйти</a>
                </li>
            </ul>
            <div class="main">
                <div class="information">
                    <p>
                    Направление: Брянск - Москва <br>
                    В пути: 6ч <br>
                    Остановок: 8шт <br>
                    Цена: 2000р <br>
                    </p>
                </div>
                <div class="information">
                    <p>
                    Направление: Санкт-Петербург - Тула <br>
                    В пути: 6ч <br>
                    Остановок: 8шт <br>
                    Цена: 2000р <br>
                    </p>
                </div>
                <div class="information">
                    <p>
                    Направление: Уфа - Красноярск <br>
                    В пути: 6ч <br>
                    Остановок: 8шт <br>
                    Цена: 2000р <br>
                    </p>
                </div>
                <div class="information">
                    <p>
                    Направление: Курск - Орёл <br>
                    В пути: 6ч <br>
                    Остановок: 8шт <br>
                    Цена: 2000р <br>
                    </p>
                </div>
                <div class="information">
                    <p>
                    Направление: Брянск - Москва <br>
                    В пути: 6ч <br>
                    Остановок: 8шт <br>
                    Цена: 2000р <br>
                    </p>
                </div>
            </div>
        </div>
    </main>
</body>

</html>